README - PRÀCTICA 4 - NUI

Donat que el codi del fitxer NUI_prac4.ipynb ens donava problemes de tabulacions/espais que no ens ha permes executar cap prova, en aquesta pràctica hem creat 3 fitxers .py amb cada un dels 3 exercicis amb què compta la pràctica. Tot i aixi, el codi esta disponible al notebook d'Ipython tot i que, per a nosaltres, no ha sigut possible executar-lo.